修改crx为rar，
然后解压，
打开chrome
加载打开这个文件夹
就能看到麦殼兒 (Maikr)0.12.5
